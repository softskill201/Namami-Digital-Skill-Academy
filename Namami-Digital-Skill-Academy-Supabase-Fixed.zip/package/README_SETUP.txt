NAMAMI DIGITAL SKILLS ACADEMY - SUPABASE FIX

1. Open Supabase project:
   https://satccuwqbhqrgffkflny.supabase.co

2. SQL Editor -> New query.
3. Copy ALL text from setup_supabase.sql and Run.
4. Confirm Table Editor -> exam_results exists.
5. Upload the included index.html, admin.html, config.js and logo.png to GitHub.
6. config.js already contains the supplied project URL and publishable key.
7. Student URL: index.html
8. Admin URL: admin.html
9. Create/login the admin user in Supabase Authentication -> Users.

The HTML design and exam questions are preserved. The index.html save routine
now gives a clearer error and retries without client_exam_id only for legacy
UUID/column errors.
