-- =============================================================
-- NAMAMI DIGITAL SKILLS ACADEMY - EXAM RESULTS SETUP
-- Run this ONCE in Supabase SQL Editor.
-- It preserves the existing exam design and creates/fixes only
-- the database structure and RLS permissions used by the site.
-- =============================================================

create extension if not exists pgcrypto;

create table if not exists public.exam_results (
    id uuid primary key default gen_random_uuid(),
    student_name text,
    student_id text,
    exam_name text,
    total_questions integer,
    correct_answers integer,
    wrong_answers integer,
    unanswered integer,
    percentage numeric(6,2),
    result text,
    duration_seconds integer,
    client_exam_id uuid,
    submitted_at timestamptz default now(),
    created_at timestamptz default now()
);

-- Add any missing columns without deleting existing records.
alter table public.exam_results add column if not exists student_name text;
alter table public.exam_results add column if not exists student_id text;
alter table public.exam_results add column if not exists exam_name text;
alter table public.exam_results add column if not exists total_questions integer;
alter table public.exam_results add column if not exists correct_answers integer;
alter table public.exam_results add column if not exists wrong_answers integer;
alter table public.exam_results add column if not exists unanswered integer;
alter table public.exam_results add column if not exists percentage numeric(6,2);
alter table public.exam_results add column if not exists result text;
alter table public.exam_results add column if not exists duration_seconds integer;
alter table public.exam_results add column if not exists client_exam_id uuid;
alter table public.exam_results add column if not exists submitted_at timestamptz;
alter table public.exam_results add column if not exists created_at timestamptz;

alter table public.exam_results alter column id set default gen_random_uuid();
alter table public.exam_results alter column submitted_at set default now();
alter table public.exam_results alter column created_at set default now();

-- RLS
alter table public.exam_results enable row level security;

-- Remove duplicate/old policies with these names.
drop policy if exists "Students can insert exam results" on public.exam_results;
drop policy if exists "Admin can view exam results" on public.exam_results;
drop policy if exists "Admin can delete exam results" on public.exam_results;

-- Students use the publishable key, therefore INSERT is allowed to anon.
create policy "Students can insert exam results"
on public.exam_results
for insert
to anon
with check (true);

-- Admin page logs in through Supabase Auth, therefore it is authenticated.
create policy "Admin can view exam results"
on public.exam_results
for select
to authenticated
using (true);

create policy "Admin can delete exam results"
on public.exam_results
for delete
to authenticated
using (true);

-- Required table grants.
grant usage on schema public to anon, authenticated;
grant insert on table public.exam_results to anon;
grant select, delete on table public.exam_results to authenticated;

-- Helpful indexes.
create index if not exists exam_results_submitted_at_idx
on public.exam_results (submitted_at desc);

create index if not exists exam_results_student_id_idx
on public.exam_results (student_id);

create index if not exists exam_results_student_name_idx
on public.exam_results (student_name);

-- =============================================================
-- END
-- =============================================================
